//
//  ViewController.swift
//  MidTerm_MADF2017
//
//  Created by moxDroid on 2017-10-20.
//  Copyright © 2017 moxDroid. All rights reserved.
//  Student ID :C0702567
//  Student Name : jaspreet kaur

import UIKit

class LoginViewController : UIViewController {

    @IBOutlet weak var tfuserId: UITextField!
    
    @IBOutlet weak var tfpassword: UITextField!
    
    @IBOutlet weak var btnLogin: UIButton!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


    @IBAction func btnLogin(_ sender: UIButton) {
        
        if tfuserId.text == "c0702567" && tfpassword.text == "jaspreet"
    {
            let alert = UIAlertController.init(title: "Alert", message: "welcome", preferredStyle: .alert)
            let action1 = UIAlertAction(title: "OK", style: .default, handler: {action in self.segue()})
            alert.addAction(action1)
            self.present(alert, animated: true, completion: nil)
            
        }
        else {
            
            let alert = UIAlertController.init(title: "Alert", message: "Password is incorrect", preferredStyle: .alert)
            let action1 = UIAlertAction(title: "OK", style: .destructive, handler: nil)
            alert.addAction(action1)
            self.present(alert, animated: true, completion: nil)
            
        }
        
    }
    func segue ()
       {
        let storyBorad = UIStoryboard.init(name: "Main", bundle: nil)
        let stuVC = storyBorad.instantiateViewController(withIdentifier: "studentEntryViewController") as! StudentEntryViewController
        self.present(stuVC, animated: true, completion: nil)
    }
    
    
}

