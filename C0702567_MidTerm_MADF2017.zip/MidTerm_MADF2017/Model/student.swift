//
//  student.swift
//  MidTerm_MADF2017
//
//  Created by MacStudent on 2017-10-20.
//  Copyright © 2017 moxDroid. All rights reserved.
//

import Foundation
class student{
    
    var stuName : String!
    var email : String!
    var birthDate :Date!
    //static var student :[Int:student]()
     //init()
     //{
        //self.stuName = ""
       // self.email = ""
       //self.birthDate =
    
       // init(_stuName :String,_email:String,_birthday:Date)
         //   _stuName = ""
          //   _email = ""
          //  _birthDate =
        
        
        
    
   // }
}

